﻿using System.Collections.Generic;

namespace PROG_POE_ST10079507
{
    // Represents an undirected graph using an adjacency list
    public class Graph
    {
        // Dictionary to store the adjacency list
        // Key: Node, Value: List of connected nodes 
        private Dictionary<int, List<int>> adjacencyList;

        // Constructor to initialize the graph
        public Graph()
        {
            adjacencyList = new Dictionary<int, List<int>>(); // Creates an empty adjacency list
        }

        // Adds an edge between source and destination in the graph
        public void AddEdge(int source, int destination)
        {
            // Ensure the source node exists in the adjacency list
            if (!adjacencyList.ContainsKey(source))
                adjacencyList[source] = new List<int>();

            // Ensure the destination node exists in the adjacency list
            if (!adjacencyList.ContainsKey(destination))
                adjacencyList[destination] = new List<int>();

            // Add the destination to the source's adjacency list
            adjacencyList[source].Add(destination);

            // Add the source to the destination's adjacency list 
            adjacencyList[destination].Add(source);
        }

        // Performs a BFS starting from a given node
        public List<int> BFS(int start)
        {
            var visited = new HashSet<int>(); // Tracks visited nodes
            var queue = new Queue<int>();    // Queue for BFS traversal
            var result = new List<int>();    // Stores the BFS traversal result

            // Start BFS from the given node
            queue.Enqueue(start);   // Add the starting node to the queue
            visited.Add(start);     // Mark the starting node as visited

            // Continue BFS until the queue is empty
            while (queue.Count > 0)
            {
                int node = queue.Dequeue(); // Remove the front node from the queue
                result.Add(node);          // Add the node to the result list

                // Visit all neighbors of the current node
                foreach (var neighbor in adjacencyList[node])
                {
                    // If the neighbor hasn't been visited, add it to the queue
                    if (!visited.Contains(neighbor))
                    {
                        visited.Add(neighbor); // Mark the neighbor as visited
                        queue.Enqueue(neighbor); // Add the neighbor to the queue
                    }
                }
            }

            return result; // Return the BFS traversal order
        }

        // Performs a Depth-First Search (DFS) starting from a given node
        public List<int> DFS(int start)
        {
            var visited = new HashSet<int>(); // Tracks visited nodes
            var stack = new Stack<int>();    // Stack for DFS traversal
            var result = new List<int>();    // Stores the DFS traversal result

            stack.Push(start); // Add the starting node to the stack

            // Continue DFS until the stack is empty
            while (stack.Count > 0)
            {
                int node = stack.Pop(); // Remove the top node from the stack

                // If the node hasn't been visited, process it
                if (!visited.Contains(node))
                {
                    visited.Add(node);   // Mark the node as visited
                    result.Add(node);    // Add the node to the result list

                    // Add all neighbors of the node to the stack
                    foreach (var neighbor in adjacencyList[node])
                    {
                        stack.Push(neighbor); // Push neighbors to the stack
                    }
                }
            }

            return result; // Return the DFS traversal order
        }
    }
}

