﻿using System;

namespace PROG_POE_ST10079507
{
    
    public class Event
    {
        // Properties to store details about the event
        public string Name { get; set; }      // Name of the event
        public string Category { get; set; } // Category or type of the event
        public DateTime Date { get; set; }   // Date when the event is scheduled

        // Constructor to initialize the Event object with specific details
        public Event(string name, string category, DateTime date)
        {
            Name = name;        
            Category = category; 
            Date = date;         
        }

       
        public override string ToString()
        {
            // method returns a string combining the event's name, category, and date in a readable format
            return $"{Name} - {Category} - {Date.ToShortDateString()}";
        }
    }
}

