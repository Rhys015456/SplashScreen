﻿using System;
using System.Windows.Forms;

namespace PROG_POE_ST10079507
{
    // Partial class for the ServiceRequestStatusForm
    public partial class ServiceRequestStatusForm : Form
    {
        // Field to store a reference to the ServiceRequestManager
        private ServiceRequestManager manager;

        // Constructor: Initializes the form and sets the ServiceRequestManager instance
        public ServiceRequestStatusForm(ServiceRequestManager serviceRequestManager)
        {
            InitializeComponent(); 
            manager = serviceRequestManager; 
        }

        // Event handler for the form's Load event
        private void ServiceRequestStatusForm_Load(object sender, EventArgs e)
        {
            // Bind all service requests from the manager to the DataGridView control for display
            dataGridViewRequests.DataSource = manager.GetAllRequests();
        }

        // Event handler for the Search button click
        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Retrieve the entered search ID from the text box, trimming whitespace
            string searchId = txtSearchId.Text.Trim();

            // Use the manager to find the service request by ID
            var request = manager.FindRequest(searchId);

            // Check if a matching service request is found
            if (request != null)
            {
                // Display the details of the found service request in a message box
                MessageBox.Show($"Found:\nID: {request.Id}\nDescription: {request.Description}\nStatus: {request.Status}");
            }
            else
            {
                // Inform the user if no matching service request is found
                MessageBox.Show("Service Request not found.");
            }
        }

        // Event handler for the Back button click
        private void btnBack_Click(object sender, EventArgs e)
        {
           
            this.Close();
        }
    }
}


