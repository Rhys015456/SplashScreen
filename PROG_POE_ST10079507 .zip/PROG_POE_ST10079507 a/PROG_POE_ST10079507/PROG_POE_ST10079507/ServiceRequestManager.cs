﻿using System.Collections.Generic;

namespace PROG_POE_ST10079507
{
    // Manages a collection of service requests
    public class ServiceRequestManager
    {
        // List to store all service requests
        private List<ServiceRequest> serviceRequests;

        // Constructor to initialize the serviceRequests list
        public ServiceRequestManager()
        {
            serviceRequests = new List<ServiceRequest>();
        }

        // Adds a new service request to the list
        public void AddRequest(ServiceRequest request)
        {
            serviceRequests.Add(request); // Adds the given request to the collection
        }

        // Finds and returns a service request by its unique ID
        public ServiceRequest FindRequest(string id)
        {
            // Searches the list for a request with the matching ID
            return serviceRequests.Find(request => request.Id == id);
        }

        // Returns all service requests as a new list
        public List<ServiceRequest> GetAllRequests()
        {
            // Creates and returns a copy of the serviceRequests list
            return new List<ServiceRequest>(serviceRequests);
        }
    }
}


