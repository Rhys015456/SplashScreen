﻿namespace PROG_POE_ST10079507
{
    public class ServiceRequest
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }

        public ServiceRequest(string id, string description, string status, string priority)
        {
            Id = id;
            Description = description;
            Status = status;
            Priority = priority;
        }
    }
}



