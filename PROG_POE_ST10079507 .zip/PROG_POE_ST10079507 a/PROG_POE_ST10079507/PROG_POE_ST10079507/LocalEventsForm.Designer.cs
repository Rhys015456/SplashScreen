﻿using System.Windows.Forms;

namespace PROG_POE_ST10079507
{
    partial class LocalEventsForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox listBoxEvents;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ListBox listBoxSearchResults;
        private System.Windows.Forms.ListBox listBoxRecommendations;
        private System.Windows.Forms.Label labelSampleEvents;
        private System.Windows.Forms.Label labelSearchResults;
        private System.Windows.Forms.Label labelRecommendations;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button btnBack;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.listBoxEvents = new System.Windows.Forms.ListBox();
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.listBoxSearchResults = new System.Windows.Forms.ListBox();
            this.listBoxRecommendations = new System.Windows.Forms.ListBox();
            this.labelSampleEvents = new System.Windows.Forms.Label();
            this.labelSearchResults = new System.Windows.Forms.Label();
            this.labelRecommendations = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxEvents
            // 
            this.listBoxEvents.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxEvents.ItemHeight = 16;
            this.listBoxEvents.Location = new System.Drawing.Point(16, 39);
            this.listBoxEvents.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxEvents.Name = "listBoxEvents";
            this.listBoxEvents.Size = new System.Drawing.Size(479, 116);
            this.listBoxEvents.TabIndex = 10;
            // 
            // comboBoxCategory
            // 
            this.comboBoxCategory.Location = new System.Drawing.Point(16, 197);
            this.comboBoxCategory.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxCategory.Name = "comboBoxCategory";
            this.comboBoxCategory.Size = new System.Drawing.Size(199, 24);
            this.comboBoxCategory.TabIndex = 9;
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.BackColor = System.Drawing.Color.LightGreen;
            this.btnSearch.Location = new System.Drawing.Point(400, 197);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(100, 28);
            this.btnSearch.TabIndex = 7;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // listBoxSearchResults
            // 
            this.listBoxSearchResults.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxSearchResults.ItemHeight = 16;
            this.listBoxSearchResults.Location = new System.Drawing.Point(16, 258);
            this.listBoxSearchResults.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxSearchResults.Name = "listBoxSearchResults";
            this.listBoxSearchResults.Size = new System.Drawing.Size(479, 116);
            this.listBoxSearchResults.TabIndex = 5;
            // 
            // listBoxRecommendations
            // 
            this.listBoxRecommendations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxRecommendations.ItemHeight = 16;
            this.listBoxRecommendations.Location = new System.Drawing.Point(16, 418);
            this.listBoxRecommendations.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxRecommendations.Name = "listBoxRecommendations";
            this.listBoxRecommendations.Size = new System.Drawing.Size(479, 116);
            this.listBoxRecommendations.TabIndex = 3;
            // 
            // labelSampleEvents
            // 
            this.labelSampleEvents.BackColor = System.Drawing.Color.Transparent;
            this.labelSampleEvents.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSampleEvents.Location = new System.Drawing.Point(16, 15);
            this.labelSampleEvents.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSampleEvents.Name = "labelSampleEvents";
            this.labelSampleEvents.Size = new System.Drawing.Size(267, 25);
            this.labelSampleEvents.TabIndex = 11;
            this.labelSampleEvents.Text = "Upcoming Events:";
            // 
            // labelSearchResults
            // 
            this.labelSearchResults.BackColor = System.Drawing.Color.Transparent;
            this.labelSearchResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearchResults.Location = new System.Drawing.Point(16, 234);
            this.labelSearchResults.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSearchResults.Name = "labelSearchResults";
            this.labelSearchResults.Size = new System.Drawing.Size(267, 25);
            this.labelSearchResults.TabIndex = 6;
            this.labelSearchResults.Text = "Search Results:";
            // 
            // labelRecommendations
            // 
            this.labelRecommendations.BackColor = System.Drawing.Color.Transparent;
            this.labelRecommendations.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRecommendations.Location = new System.Drawing.Point(16, 394);
            this.labelRecommendations.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRecommendations.Name = "labelRecommendations";
            this.labelRecommendations.Size = new System.Drawing.Size(267, 25);
            this.labelRecommendations.TabIndex = 4;
            this.labelRecommendations.Text = "Recommended Events:";
            // 
            // labelCategory
            // 
            this.labelCategory.BackColor = System.Drawing.Color.Transparent;
            this.labelCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCategory.Location = new System.Drawing.Point(16, 172);
            this.labelCategory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(133, 28);
            this.labelCategory.TabIndex = 2;
            this.labelCategory.Text = "Category:";
            // 
            // labelDate
            // 
            this.labelDate.BackColor = System.Drawing.Color.Transparent;
            this.labelDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.Location = new System.Drawing.Point(240, 172);
            this.labelDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(133, 28);
            this.labelDate.TabIndex = 1;
            this.labelDate.Text = "Date:";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker.Location = new System.Drawing.Point(240, 197);
            this.dateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(132, 22);
            this.dateTimePicker.TabIndex = 8;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.BackColor = System.Drawing.Color.Salmon;
            this.btnBack.Location = new System.Drawing.Point(400, 554);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 28);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // LocalEventsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.ClientSize = new System.Drawing.Size(533, 615);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.labelCategory);
            this.Controls.Add(this.listBoxRecommendations);
            this.Controls.Add(this.labelRecommendations);
            this.Controls.Add(this.listBoxSearchResults);
            this.Controls.Add(this.labelSearchResults);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.comboBoxCategory);
            this.Controls.Add(this.listBoxEvents);
            this.Controls.Add(this.labelSampleEvents);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "LocalEventsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Local Events and Announcements";
            this.ResumeLayout(false);

        }
    }
}

