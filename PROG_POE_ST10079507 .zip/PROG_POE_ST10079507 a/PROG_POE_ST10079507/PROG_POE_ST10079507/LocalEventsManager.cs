﻿using System;
using System.Collections.Generic;
using System.Linq;

public class LocalEventsManager
{
    // a Dictionary to store events by category using
    private Dictionary<string, Queue<Event>> eventsByCategory;

    // SortedDictionary to keep events sorted by date
    private SortedDictionary<DateTime, List<Event>> eventsByDate;

    //  HashSet to track unique categories 
    private HashSet<string> uniqueCategories;

    // Stack to store user search history/last searched categories
    private Stack<string> searchHistory;

    public LocalEventsManager()
    {
        eventsByCategory = new Dictionary<string, Queue<Event>>();
        eventsByDate = new SortedDictionary<DateTime, List<Event>>();
        uniqueCategories = new HashSet<string>();
        searchHistory = new Stack<string>();

        // Populate with some sample events
        AddSampleEvents();
    }

    // Sample events for testing
    private void AddSampleEvents()
    {
        AddEvent("Sports", "VC CUP Football Match", DateTime.Today.AddDays(1));
        AddEvent("Education", "VC SOIT AI Workshop", DateTime.Today.AddDays(3));
        AddEvent("Entertainment", "VC School Fundraising Concert", DateTime.Today.AddDays(2));
        AddEvent("Sports", "VC Interschool Tennis Match", DateTime.Today.AddDays(1));
    }

    // Add an event to both data structures
    public void AddEvent(string category, string eventName, DateTime date)
    {
        if (!eventsByCategory.ContainsKey(category))
        {
            eventsByCategory[category] = new Queue<Event>();
            uniqueCategories.Add(category);  // Tracking unique categories
        }

        var newEvent = new Event { Name = eventName, Date = date };

        eventsByCategory[category].Enqueue(newEvent);

        if (!eventsByDate.ContainsKey(date))
            eventsByDate[date] = new List<Event>();

        eventsByDate[date].Add(newEvent);
    }

    // Getting all the upcoming events from the SortedDictionary
    public List<Event> GetAllUpcomingEvents()
    {
        var allEvents = new List<Event>();

        // Loop through all events sorted by date
        foreach (var dateEvents in eventsByDate.Values)
        {
            allEvents.AddRange(dateEvents);
        }

        return allEvents;
    }

    // Search for events by category and then track the search in a stack
    public List<Event> SearchEvents(string category, DateTime selectedDate)
    {
        if (!eventsByCategory.ContainsKey(category)) return new List<Event>();

        // Tracking the search history using a stack
        searchHistory.Push(category);

        return eventsByCategory[category]
            .Where(e => e.Date.Date == selectedDate.Date)
            .ToList();
    }

    // Getting recommendations based on the user's search history
    public List<Event> GetRecommendations()
    {
        var recommendations = new List<Event>();

        // Using the search history to suggest similar events
        if (searchHistory.Count > 0)
        {
            string lastSearchedCategory = searchHistory.Peek();

            if (eventsByCategory.ContainsKey(lastSearchedCategory))
            {
                recommendations.AddRange(eventsByCategory[lastSearchedCategory]);
            }
        }

        return recommendations;
    }

    // Geting all the unique categories using a HashSet
    public HashSet<string> GetCategories()
    {
        return uniqueCategories;
    }
}

// Event class to represent each event
public class Event
{
    public string Name { get; set; }
    public DateTime Date { get; set; }

    public override string ToString()
    {
        return $"{Name} on {Date.ToShortDateString()}";
    }
}
