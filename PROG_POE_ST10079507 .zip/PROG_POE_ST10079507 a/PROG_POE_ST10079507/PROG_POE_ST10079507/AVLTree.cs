﻿using System;
using System.Collections.Generic;

namespace PROG_POE_ST10079507
{
    // AVLTree class provides functionality for an AVL self-balancing binary search tree
    public class AVLTree
    {
        // Node class represents a single node in the AVL tree
        public class Node
        {
            public ServiceRequest Data; // Data stored in the node, representing a service request
            public Node Left;           // Pointer to the left child node
            public Node Right;          // Pointer to the right child node
            public int Height;          // Height of the node, used for balancing

            // Constructor to initialize a node with service request data
            public Node(ServiceRequest data)
            {
                Data = data;
                Left = null;           // No left child initially
                Right = null;          // No right child initially
                Height = 1;            // Height of a new node is 1 /leaf node
            }
        }

        private Node root; // Root node of the AVL tree

        // Inserts a new service request into the tree
        public void Insert(ServiceRequest request)
        {
            root = Insert(root, request); // Calls the private recursive insert method
        }

        // Private recursive method to insert a service request into the tree
        private Node Insert(Node node, ServiceRequest request)
        {
            // If the current node is null, create a new node with the service request
            if (node == null)
                return new Node(request);

            // Compare the IDs (strings) to determine whether to insert into the left or right subtree
            if (string.Compare(request.Id, node.Data.Id) < 0)
                node.Left = Insert(node.Left, request); // Insert into the left subtree
            else if (string.Compare(request.Id, node.Data.Id) > 0)
                node.Right = Insert(node.Right, request); // Insert into the right subtree
            else
                return node; // Duplicate IDs are not allowed; return the existing node

            // Update the height of the current node after insertion
            node.Height = 1 + Math.Max(Height(node.Left), Height(node.Right));

            // Balance the node if it becomes unbalanced
            return Balance(node);
        }

        // Searches for a service request by ID and returns it
        public ServiceRequest Search(string id)
        {
            return Search(root, id)?.Data; // Calls the private recursive search method
        }

        // Private recursive method to search for a service request by ID
        private Node Search(Node node, string id)
        {
            // Base case: node is null or the ID matches the current node's data
            if (node == null || node.Data.Id == id)
                return node;

            // Compare the IDs to decide whether to search the left or right subtree
            return string.Compare(id, node.Data.Id) < 0 ? Search(node.Left, id) : Search(node.Right, id);
        }

        // Returns a list of all service requests in sorted order/ in-order traversal
        public List<ServiceRequest> InOrderTraversal()
        {
            var result = new List<ServiceRequest>(); // List to store the results
            InOrderTraversal(root, result);          // Calls the private recursive traversal method
            return result;                           // Returns the sorted list
        }

        // Private recursive method to perform in-order traversal of the tree
        private void InOrderTraversal(Node node, List<ServiceRequest> result)
        {
            if (node != null)
            {
                InOrderTraversal(node.Left, result);  // Traverse the left subtree
                result.Add(node.Data);               // Add the current node's data to the result
                InOrderTraversal(node.Right, result); // Traverse the right subtree
            }
        }

        // Returns the height of a node; if the node is null, the height is 0
        private int Height(Node node)
        {
            return node?.Height ?? 0; // Null-coalescing operator to handle null nodes
        }

        // Balances the given node and returns the balanced node
        private Node Balance(Node node)
        {
            int balanceFactor = GetBalance(node); // Calculate the balance factor of the node

            // Left-heavy case: Perform a right rotation
            if (balanceFactor > 1 && GetBalance(node.Left) >= 0)
                return RotateRight(node);

            // Left-right-heavy case: Perform a left rotation on the left child, then a right rotation
            if (balanceFactor > 1 && GetBalance(node.Left) < 0)
            {
                node.Left = RotateLeft(node.Left);
                return RotateRight(node);
            }

            // Right-heavy case: Perform a left rotation
            if (balanceFactor < -1 && GetBalance(node.Right) <= 0)
                return RotateLeft(node);

            // Right-left-heavy case: Perform a right rotation on the right child, then a left rotation
            if (balanceFactor < -1 && GetBalance(node.Right) > 0)
            {
                node.Right = RotateRight(node.Right);
                return RotateLeft(node);
            }

            return node; // Return the balanced node
        }

        // Calculates the balance factor of a node
        private int GetBalance(Node node)
        {
            // Balance factor = height of left subtree - height of right subtree
            return node == null ? 0 : Height(node.Left) - Height(node.Right);
        }

        // Performs a right rotation to balance the tree
        private Node RotateRight(Node y)
        {
            Node x = y.Left;  // Set the left child as the new root of the subtree
            Node T = x.Right; // Save the right subtree of the new root

            // Perform rotation
            x.Right = y; // Original root becomes the right child
            y.Left = T;  // Attach the saved subtree to the original root's left

            // Update heights of the nodes
            y.Height = Math.Max(Height(y.Left), Height(y.Right)) + 1;
            x.Height = Math.Max(Height(x.Left), Height(x.Right)) + 1;

            return x; // Return the new root of the subtree
        }

        // Performs a left rotation to balance the tree
        private Node RotateLeft(Node x)
        {
            Node y = x.Right; // Set the right child as the new root of the subtree
            Node T = y.Left;  // Save the left subtree of the new root

            // Perform rotation
            y.Left = x;  // Original root becomes the left child
            x.Right = T; // Attach the saved subtree to the original root's right

            // Update heights of the nodes
            x.Height = Math.Max(Height(x.Left), Height(x.Right)) + 1;
            y.Height = Math.Max(Height(y.Left), Height(y.Right)) + 1;

            return y; // Return the new root of the subtree
        }
    }
}

