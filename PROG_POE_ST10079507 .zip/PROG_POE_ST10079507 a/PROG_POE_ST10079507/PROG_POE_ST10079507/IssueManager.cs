﻿using System.Collections.Generic;

namespace PROG_POE_ST10079507
{
    public class IssueManager
    {
        private List<Issue> issuesList;  // Store issues in a List

        // Constructor to initialize the list
        public IssueManager()
        {
            issuesList = new List<Issue>();
        }

        // Adding a new issue
        public void AddIssue(Issue issue)
        {
            issuesList.Add(issue);
        }

        // Retrieves all the issues for a specific location
        public List<Issue> GetIssuesByLocation(string location)
        {
            List<Issue> issuesAtLocation = new List<Issue>();

            foreach (Issue issue in issuesList)
            {
                if (issue.Location == location)
                {
                    issuesAtLocation.Add(issue);
                }
            }

            return issuesAtLocation;
        }

        // Gets the all issues 
        public List<Issue> GetAllIssues()
        {
            return issuesList;
        }
    }
}
