﻿using System;

namespace PROG_POE_ST10079507
{
    // Represents a single node in the Binary Search Tree
    public class BinarySearchTreeNode<T>
    {
        public T Value { get; set; }                 // Value stored in the node
        public BinarySearchTreeNode<T> Left { get; set; }  // Pointer to the left child node
        public BinarySearchTreeNode<T> Right { get; set; } // Pointer to the right child node

        // Constructor to initialize the node with a value
        public BinarySearchTreeNode(T value)
        {
            Value = value;  // Assign the value to the node
            Left = null;    // Initially, there is no left child
            Right = null;   // Initially, there is no right child
        }
    }

    // Implements a Binary Search Tree for managing service requests
    public class BinarySearchTree
    {
        private BinarySearchTreeNode<ServiceRequest> root; // Root of the tree

        // Constructor initializes the tree with an empty root
        public BinarySearchTree()
        {
            root = null; // The tree starts empty
        }

        // Public method to insert a service request into the tree
        public void Insert(ServiceRequest request)
        {
            root = InsertRecursively(root, request); // Calls the recursive insert method
        }

        // Recursive method to insert a service request into the tree
        public BinarySearchTreeNode<ServiceRequest> InsertRecursively(BinarySearchTreeNode<ServiceRequest> node, ServiceRequest request)
        {
            // If the current node is null, create a new node for the service request
            if (node == null)
                return new BinarySearchTreeNode<ServiceRequest>(request);

            // Compare the IDs to decide whether to insert into the left or right subtree
            if (string.Compare(request.Id, node.Value.Id) < 0)
                node.Left = InsertRecursively(node.Left, request); // Insert into the left subtree
            else if (string.Compare(request.Id, node.Value.Id) > 0)
                node.Right = InsertRecursively(node.Right, request); // Insert into the right subtree

            return node; // Return the updated node
        }

        // Public method to search for a service request by ID
        public ServiceRequest Search(string id)
        {
            return SearchRecursively(root, id); // Calls the recursive search method
        }

        // Recursive method to search for a service request by ID
        public ServiceRequest SearchRecursively(BinarySearchTreeNode<ServiceRequest> node, string id)
        {
            // Base case: node is null or the ID matches the current node's value
            if (node == null)
                return null;

            if (id == node.Value.Id)
                return node.Value;

            // Compare the IDs to decide whether to search in the left or right subtree
            if (string.Compare(id, node.Value.Id) < 0)
                return SearchRecursively(node.Left, id); // Search in the left subtree

            return SearchRecursively(node.Right, id); // Search in the right subtree
        }
    }
}

