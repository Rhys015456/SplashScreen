﻿namespace PROG_POE_ST10079507
{
    public class Issue
    {
        public string Location { get; set; }
        public string StreetName { get; set; }
        public string Area { get; set; }
        public string City { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }

        // Constructor to create issue object
        public Issue(string location, string streetName, string area, string city, string category, string description)
        {
            Location = location;
            StreetName = streetName;
            Area = area;
            City = city;
            Category = category;
            Description = description;
        }

       
        public Issue()
        {
        }
    }
}
