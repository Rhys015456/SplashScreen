﻿using System;
using System.Windows.Forms;

namespace PROG_POE_ST10079507
{
    public partial class MainForm : Form
    {
        private ServiceRequestManager serviceRequestManager;

        public MainForm()
        {
            InitializeComponent();
            serviceRequestManager = new ServiceRequestManager();

            // Sample Data
            serviceRequestManager.AddRequest(new ServiceRequest("1", "Repair Road", "Open", "High"));
            serviceRequestManager.AddRequest(new ServiceRequest("2", "Fix Streetlight", "Completed", "Medium"));
            serviceRequestManager.AddRequest(new ServiceRequest("3", "Fix Manhole Cover", "Open", "High"));
            serviceRequestManager.AddRequest(new ServiceRequest("4", "Water Leak", "Completed", "Low"));
            serviceRequestManager.AddRequest(new ServiceRequest("5", "Repair Sewage Pipe", "Open", "High"));
        }

        // Click Handler for Report Issues Button
        private void btnReportIssues_Click(object sender, EventArgs e)
        {
            ReportIssues reportIssuesForm = new ReportIssues();
            reportIssuesForm.ShowDialog();
        }

        // Local Events and Announcements Button Click Handler
        private void btnLocalEvents_Click(object sender, EventArgs e)
        {
            LocalEventsForm localEventsForm = new LocalEventsForm(this); // Passing the MainForm instance
            this.Hide(); // To Hide the MainForm when opening LocalEventsForm
            localEventsForm.Show(); // Opening LocalEventsForm
        }

        // Service Request Status Button Click Handler
        private void btnServiceStatus_Click(object sender, EventArgs e)
        {
            ServiceRequestStatusForm statusForm = new ServiceRequestStatusForm(serviceRequestManager);
            statusForm.ShowDialog();
        }

        // MainForm Load Event
        private void MainForm_Load(object sender, EventArgs e)
        {
            label1.Left = (this.ClientSize.Width - label1.Width) / 2;
            label2.Left = (this.ClientSize.Width - label2.Width) / 2;

            btnLocalEvents.Enabled = true;
            btnServiceStatus.Enabled = true; // Enable the Service Status button
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
