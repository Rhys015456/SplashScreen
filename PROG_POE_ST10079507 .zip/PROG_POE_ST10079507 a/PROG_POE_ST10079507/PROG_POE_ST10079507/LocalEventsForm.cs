﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PROG_POE_ST10079507
{
    public partial class LocalEventsForm : Form
    {
        private MainForm mainForm;
        private LocalEventsManager eventsManager;

        public LocalEventsForm(MainForm callingForm)
        {
            InitializeComponent();
            mainForm = callingForm;
            eventsManager = new LocalEventsManager();

            this.Resize += LocalEventsForm_Resize;  // Resizing the Register Event

            DisplayUpcomingEvents();
            PopulateCategoryDropdown();
        }

        //Resizing adjusments handler
        private void LocalEventsForm_Resize(object sender, EventArgs e)
        {
            listBoxEvents.Width = this.ClientSize.Width - 24;
            listBoxSearchResults.Width = this.ClientSize.Width - 24;
            listBoxRecommendations.Width = this.ClientSize.Width - 24;

            btnBack.Left = this.ClientSize.Width - btnBack.Width - 12;
            btnBack.Top = this.ClientSize.Height - btnBack.Height - 12;
        }

        // Display for the upcoming events
        private void DisplayUpcomingEvents()
        {
            listBoxEvents.Items.Clear();
            var upcomingEvents = eventsManager.GetAllUpcomingEvents();

            foreach (var ev in upcomingEvents)
            {
                listBoxEvents.Items.Add(ev.ToString());
            }
        }

        // Populates the dropdown box
        private void PopulateCategoryDropdown()
        {
            comboBoxCategory.Items.Clear();

            foreach (var category in eventsManager.GetCategories())
            {
                comboBoxCategory.Items.Add(category);
            }
        }

        // search button click handler 
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (comboBoxCategory.SelectedItem == null)
            {
                MessageBox.Show("Please select a category.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string category = comboBoxCategory.SelectedItem.ToString();
            DateTime selectedDate = dateTimePicker.Value.Date;

            var searchResults = eventsManager.SearchEvents(category, selectedDate);

            listBoxSearchResults.Items.Clear();
            foreach (var ev in searchResults)
            {
                listBoxSearchResults.Items.Add(ev.ToString());
            }

            DisplayRecommendations();
        }

        //recommenedations will populate based on search history
        private void DisplayRecommendations()
        {
            listBoxRecommendations.Items.Clear();
            var recommendations = eventsManager.GetRecommendations();

            foreach (var ev in recommendations)
            {
                listBoxRecommendations.Items.Add(ev.ToString());
            }
        }

        //Back button click handler
        private void btnBack_Click(object sender, EventArgs e)
        {
            mainForm.Show();
            this.Close();
        }
    }
}
