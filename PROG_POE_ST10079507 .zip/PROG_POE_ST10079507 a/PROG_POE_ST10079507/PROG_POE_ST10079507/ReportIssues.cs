﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace PROG_POE_ST10079507
{
    public partial class ReportIssues : Form
    {
        // Declaring an instance of IssueManager
        private IssueManager issueManager;

        public ReportIssues()
        {
            InitializeComponent();
            // Initialize the IssueManager
            issueManager = new IssueManager();
        }

        //  click handler for submit button
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Getting inputs from the form fields
            string location = txtLocation.Text;
            string streetName = txtStreetName.Text;
            string area = txtArea.Text;
            string city = txtCity.Text;
            string category = listBoxCategory.SelectedItem != null ? listBoxCategory.SelectedItem.ToString() : null;
            string description = txtDescription.Text;

            // Validation to ensure all fields are filled in
            if (string.IsNullOrEmpty(location) || string.IsNullOrEmpty(streetName) || string.IsNullOrEmpty(area) ||
                string.IsNullOrEmpty(city) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Creating a new Issue instance
            Issue newIssue = new Issue
            {
                Location = location,
                StreetName = streetName,
                Area = area,
                City = city,
                Category = category,
                Description = description
            };

            // Adding the new issue using IssueManager
            issueManager.AddIssue(newIssue);

            //  success messagebox
            MessageBox.Show("Issue reported successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Resetting the form fields after submission
            ResetForm();
        }

        // Resetting the form fields after submission
        private void ResetForm()
        {
            txtLocation.Clear();
            txtStreetName.Clear();
            txtArea.Clear();
            txtCity.Clear();
            listBoxCategory.ClearSelected();
            txtDescription.Clear();
            progressBar1.Value = 0;
            lblProgressPercentage.Text = "0%";
        }

        // click handler for Attaching media
        private void btnAttachMedia_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp|All Files|*.*"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show($"File attached: {openFileDialog.FileName}", "File Attached", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateProgressBar();
            }
        }

        // Updating the progress bar as fields are filled
        private void UpdateProgressBar()
        {
            int progress = 0;

            if (!string.IsNullOrEmpty(txtLocation.Text))
                progress += 20;  // Increment by 20% if the location is filled

            if (!string.IsNullOrEmpty(txtStreetName.Text))
                progress += 20;  // Increment by 20% if the street name is filled

            if (!string.IsNullOrEmpty(txtArea.Text))
                progress += 20;  // Increment by 20% if the area is filled

            if (!string.IsNullOrEmpty(txtCity.Text))
                progress += 20;  // Increment by 20% if the city is filled

            if (listBoxCategory.SelectedItem != null)
                progress += 10;  // Increment by 10% if a category is selected

            if (!string.IsNullOrEmpty(txtDescription.Text))
                progress += 10;  // Increment by 10% if the description is filled

            // Update the progress bar and percentage label
            progressBar1.Value = progress;
            lblProgressPercentage.Text = $"{progress}%";
        }

        // Event handler for tracking user input and updating the progress bar
        private void txtLocation_TextChanged(object sender, EventArgs e)
        {
            UpdateProgressBar();
        }

        private void txtStreetName_TextChanged(object sender, EventArgs e)
        {
            UpdateProgressBar();
        }

        private void txtArea_TextChanged(object sender, EventArgs e)
        {
            UpdateProgressBar();
        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {
            UpdateProgressBar();
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
            UpdateProgressBar();
        }

        private void listBoxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateProgressBar();
        }

        // click handler for back button to close the current form
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Form load event to populate the category list with available options
        private void ReportIssues_Load(object sender, EventArgs e)
        {
            listBoxCategory.Items.AddRange(new string[] { "Sanitation", "Roads", "Utilities" });
        }
    }
}
